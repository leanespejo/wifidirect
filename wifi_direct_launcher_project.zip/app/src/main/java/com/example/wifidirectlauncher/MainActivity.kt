package com.example.wifidirectlauncher

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // We don't show any UI — immediately try to open Wi‑Fi Direct on Samsung, then fall back.
        tryOpenWifiDirect()
        finish()
    }

    private fun tryOpenWifiDirect() {
        // Candidate explicit Samsung / AOSP component names (these vary by device/OS/version).
        val candidateComponents = listOf(
            // Samsung (common guess)
            ComponentName("com.samsung.android.settings", "com.samsung.android.settings.wifi.direct.WifiDirectSettings"),
            ComponentName("com.samsung.android.settings", "com.samsung.android.settings.wifi.direct.WifiDirectActivity"),
            // AOSP / other vendors (various possible names)
            ComponentName("com.android.settings", "com.android.settings.wifi.p2p.WifiP2pSettings"),
            ComponentName("com.android.settings", "com.android.settings.Settings$WifiP2pSettingsActivity")
        )

        for (comp in candidateComponents) {
            try {
                val intent = Intent().apply {
                    component = comp
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                // If activity exists, start and return
                packageManager.getActivityInfo(comp, 0) // will throw if not found
                startActivity(intent)
                return
            } catch (e: Exception) {
                // ignore and try next
            }
        }

        // Fallback 1: regular Wi‑Fi settings
        try {
            val wifiIntent = Intent(Settings.ACTION_WIFI_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            startActivity(wifiIntent)
            return
        } catch (e: Exception) {
            // ignore
        }

        // Fallback 2: wireless settings (broader)
        try {
            val wirelessIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            startActivity(wirelessIntent)
            return
        } catch (e: Exception) {
            // ignore
        }

        // Last resort: show a toast explaining failure
        Toast.makeText(this, "Unable to open Wi‑Fi Direct settings on this device.", Toast.LENGTH_LONG).show()
    }
}
