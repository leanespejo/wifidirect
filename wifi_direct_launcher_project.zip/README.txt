WifiDirectLauncher - minimal Android Studio project
--------------------------------------------------

What this does:
- On launch the app attempts to open the Wi‑Fi Direct / P2P settings screen.
- It first attempts several Samsung/AOSP component names, then falls back to:
  1) Android Wi‑Fi settings (ACTION_WIFI_SETTINGS)
  2) Wireless settings (ACTION_WIRELESS_SETTINGS)
- If none work it shows a toast message.

How to build an APK (recommended):
1) Install Android Studio (if not already installed).
2) Open this project directory in Android Studio.
3) Let Android Studio sync and install the required SDK/Gradle tools it prompts for.
4) Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5) Locate the generated APK (in app/build/outputs/apk/). Transfer to your phone and install.

Notes:
- Exact Samsung component class names may differ by firmware. The app tries a few candidates.
- No dangerous permissions required. If the app cannot open the exact Wi‑Fi Direct page on your specific model, it will open Wi‑Fi settings instead.
- If you want a version that *always* opens a Samsung-specific activity and you confirm the exact component name on your phone, reply with that component name and I can update the project to try it first.
